import java.util.Scanner;
public class Logic {
    public static void main(String[] args)
    {
       
        boolean gameover = false;
        boolean play = true;
        boolean game = true;
        boolean P1 = false;
        boolean P2 = false;
       
       
        int ScoreP1 = 0;
        int ScoreP2 = 0;
        Board.populate();


    if (GameRunner.PVP) //accesses the PVP value from gamerunner if player selects PVP, runs this method
{
        Scanner scanner = new Scanner(System.in);
        System.out.println("Player 1, please select name.");
        String name1 = scanner.nextLine();


        System.out.println("Player 2, please select name.");
        String name2 = scanner.nextLine();
        System.out.println("There are currently " + Board.pieces + " pieces on the board.");
        System.out.println("You can take no more than 1/2 of the remaining pieces. You cannot take 0.");
        int first = (int)(Math.random() * 10);
        if (first >= 5)
        {
            P1 = true;
        } else P2 = true;


  while(play)
  {
        while(P1)
        {
            P2 = false;
            System.out.println(name1 + " please choose the amount of pieces you would like to take.");
            String take = scanner.nextLine();
            int number = Integer.parseInt(take);
            if (number <= Board.pieces / 2)
            {
                Board.pieces -= number;
                ScoreP1 += 1;
                System.out.println("There are " + Board.pieces + " left.");
            } else System.out.println("Invalid input, waste of turn."); ScoreP1 -= 1;
            if (Board.pieces == 1)
            {
                if (P1)
                {
                    System.out.println(name2 + " has lost!");
                    gameover = true;
                }
            }
            P2 = true;
            P1 = false;
           
        }


        while(P2)
        {
            P1 = false;
            System.out.println(name2 + " please choose the amount of pieces you would like to take.");
            String take = scanner.nextLine();
            int number = Integer.parseInt(take);
            if (number <= Board.pieces / 2)
            {
                Board.pieces -= number;
                ScoreP2 += 1;
                System.out.println("There are " + Board.pieces + " left.");
            } else System.out.println("Invalid input, waste of turn."); ScoreP2 -= 1;
            if (Board.pieces == 1)
            {
                if (P2)
                {
                    System.out.println(name1 + " has lost!");
                    gameover = true;
                }
            }
            P1 = true;
            P2 = false;
           
        }
        if (gameover)
        {
            play = false;
            System.out.println("The game has ended!");
            System.out.println("P1 score: " + ScoreP1);
            System.out.println("P2 score: " + ScoreP2);
            System.out.println("Replay? (Yes or No)");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("YES"))
            {
                main(null);
            } else 
            {
                System.out.println("Thanks for playing!");
            }
        }
       
    }
}
       




    }


     public static void AI(String[] args)
    {
        boolean gameover = false;
        boolean play = true;
        boolean game = true;
        boolean Player = false;
        boolean AI = false;

        if (GameRunner.AI) //accesses the AI value from gamerunner if player selects AI, runs this method
{
        Scanner scanner = new Scanner(System.in);
        System.out.println("Player, please select name.");
        String name = scanner.nextLine();


       
        System.out.println("There are currently " + Board.pieces + " pieces on the board.");
        System.out.println("You can take no more than 1/2 of the remaining pieces. You cannot take 0.");
        int first = (int)(Math.random() * 10);
        if (first >= 5)
        {
            Player = true;
        } else AI = true;


  while(play)
  {
        while(Player)
        {
            AI = false;
            System.out.println(name + " please choose the amount of pieces you would like to take.");
            String take = scanner.nextLine();
            int number = Integer.parseInt(take);
            if (number <= Board.pieces / 2)
            {
                Board.pieces -= number;
                System.out.println("There are " + Board.pieces + " left.");
            } else System.out.println("Invalid input, waste of turn."); 
            if (Board.pieces == 1)
            {
                if (Player)
                {
                    System.out.println( "AI has lost!");
                    gameover = true;
                }
            }
            AI = true;
            Player = false;
           
        }


        while(AI)
        {
            System.out.println("AI's turn...");
            Player = false;
            int AIchoice = (int)(Math.random() * Board.pieces / 2) + 1;
            System.out.println("AI takes " + AIchoice + " pieces!");
            Board.pieces -= AIchoice;
            System.out.println("There are " + Board.pieces + " left.");
            if (Board.pieces == 1)
            {
                if (AI)
                {
                    System.out.println( name + " has lost!");
                    gameover = true;
                }
            }


            Player = true;
            AI = false;
           
        }
        if (gameover)
        {
            play = false;
            System.out.println("The game has ended!");
            System.out.println("Replay? (Yes or No)");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("YES"))
            {
                AI(null);
            } else 
            {
                System.out.println("Thanks for playing!");
            }
        }
       
    }
}
    }
}
