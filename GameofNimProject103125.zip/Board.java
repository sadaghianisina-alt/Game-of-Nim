public class Board
{
    public static int pieces; //stores data


    public static void populate() //gamerunner calls this
    {
   
        pieces = (int)(Math.random() * 41) + 10;
 
    }


    public static int getPieces(){ //howmuch pieces are left
        return pieces;
    }
}
