/**
 * Project 2.2.11
 *
 * GameRunner Class for the Game of Nim
*/
import java.util.Scanner;
public class GameRunner
{
  public static boolean PVP = false;
  public static boolean AI = false;
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    System.out.println("Welcome to the Game of Nim!");
    System.out.println("PVP mode or AI mode?");
    String choice = sc.nextLine();
    if (choice.equalsIgnoreCase("PVP"))//pvp or PVP works
    {
      PVP = true;


    } else if (choice.equalsIgnoreCase("AI"))//ai or AI works
    {
      AI = true;
    } else
    {
      System.out.println("Invalid input... Choosing AI"); //chooses AI by default
      AI = true;
    }


    Board.populate(); //runs populate method from board
    if (PVP)
    {
    Logic.main(null); //automatically runs main method of logic 
    } else 
    {
        Logic.AI(null);
    }
   
  }
}
